/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package miprimeroproyectojava.app_prestamos;

/**
 *
 * @author wende
 */
public class prestamo {
    //ATributos
    private String nombreCliente, numCliente, dniCliente;
    private int cantPrestamo, plazoMeses;
    private double intAnual;
    
    // M. Constructor
    public prestamo (){}
    
    // M. Set
    public void setnumCliente(String numCliente) {this.numCliente = numCliente;}
    public void setnombreCliente(String nombreCliente) {this.nombreCliente = nombreCliente;}
    public void setdniCliente(String dniCliente) {this.dniCliente = dniCliente;}
    public void setcantPrestamo(int cantPrestamo){this.cantPrestamo = cantPrestamo;}
    public void setplazoMeses (int plazoMeses){this.plazoMeses = plazoMeses;}
    public void setintAnual(double intAnual){this.intAnual = intAnual;}
    
    //M Get
    public String getnumCliente(){return numCliente;}
    public String getnombreCliente(){return nombreCliente;}
    public String getdniCliente(){return dniCliente;}
    public int getcantPrestamo(){return cantPrestamo;}
    public int getplazoMeses(){return plazoMeses;}
    public double getintAnual (){return intAnual;}
   
}
