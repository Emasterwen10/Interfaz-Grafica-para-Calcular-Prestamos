/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package miprimeroproyectojava.app_prestamos;

/**
 *
 * @author wende
 */
public class App_Prestamos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
